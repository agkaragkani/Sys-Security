#include <stdio.h>
#include <string.h>
#include <stdlib.h>

void shell_pwn() {
    const char code[] =
        "\x48\x31\xc0\x50\x48\x89\xe2\x48\xbb\x2f\x2f\x62\x69\x6e\x2f\x73\x68\x53\x48\x89\xe7\x50\x57\x48\x89\xe6\x48\x83\xc0\x3b\x0f\x05";

    // Function pointer to cast and execute the shellcode
    void (*ret)() = (void(*)())code;

    // Call the shellcode
    ret();
}

int copytobuffer(char* input) {
    char buffer[52];

    size_t input_len = strlen(input);
    // Perform bounds checking
    if (input_len >= sizeof(buffer)) {
        fprintf(stderr, "Input is too long\n");
        exit(EXIT_FAILURE);
    }
    strncpy(buffer, input, input_len);
    buffer[input_len] = '\0';  // Ensure null-termination

    return 0;
}

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <input>\n", argv[0]);
        return EXIT_FAILURE;
    }

    int local_variable = 1;
    copytobuffer(argv[1]);

    // Optionally, you can call shell_pwn here if you want it to be executed.
    // shell_pwn();

    return 0;
}

