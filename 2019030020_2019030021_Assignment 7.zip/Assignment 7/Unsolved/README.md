# Assignment 7
## Buffer Overflow Exploitation
##### Alexandra Gkaragkani 2019030020 
###### Eva Pantazi 2019030021


## Overview
The goal was to develop a script that exploits a buffer overflow vulnerability in a program. The strategy involves overflowing the buffer on the stack, leveraging the executable nature of the "Name" array using the mprotect function, which means that the programmer introduced an extra vulnerability in the program.

## Exploit Description
The exploit takes advantage of the fact that the "Name" array is marked as executable, making it easier to execute shellcode within it rather than disabling Address Space Layout Randomization (ASLR) and running the shellcode inside the stack.

## Exploit Workflow
1. Overflow the buffer on the stack with the output of the InputGenerator script
2. The program copies the buffer into the "Name" array, which resides in the executable segment of memory. 
3. Jump to the starting address of the "Name" array + 4 bytes (where noops are placed). We found the address of it as 0x555555558040.
4. Execute shellcode, providing a user-level shell.  
## Implementation steps 
1. Run the Greeter program with a long string as input to determine the correct amount of characters needed to control the instruction pointer.
2. Identify the value of the EIP (instruction pointer) and determine the buffer size.
3. Introduce noops to the buffer to allow flexibility in executing the shellcode even if memory addresses change slightly.
4. Insert shellcode that spawns a user-level shell.

## How to run
Feed the exploit.txt directly to the program:
(cat ./exploit.txt; cat) | ./Greeter

The "Shellcode" is a test program that spawns a user-level shell for testing purposes.
Ensure the gcc-multilib package is installed:
$ sudo apt-get install gcc-multilib
Compile the shellcode using simply the make command in the makefile we created:
$ make all

or by manually typing the following commands:
$ python3 shell.py > exploit.txt
$ (cat exploit.txt ;cat)| ./Greeter
$ ls   # New terminal; execute any other desired commands

## License

[MIT](https://choosealicense.com/licenses/mit/
)
