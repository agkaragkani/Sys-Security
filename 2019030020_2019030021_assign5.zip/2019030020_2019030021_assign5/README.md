# Adblocker

Eva Pantazi, AM:2019030021

Alexandra Gkaragkani, AM:2019030020


This is a simple adblocker that uses iptables.

## Verification

To assess our program's effectiveness, we can verify its performance by attempting connections to various domains or IP addresses. If a connection fails to establish, it indicates that the domain is part of our block list. However, it's important to note that not all ads may be successfully blocked, and there are multiple reasons for this occurrence. This issue arises due to the presence of adblocker detectors on certain websites, which can successfully circumvent my adblocker or require more intricate and specialized rules than those we initially applied.

In order to run the .sh file we used the following commands:
sudo ./adblock.sh -<one of the following operations>


-domains:	Configure adblock rules based on the domain names of 'domainNames.txt' file
-ips:		Configure adblock rules based on the IP addresses of 'IPAddresses.txt' file.
-save:		Save rules to 'adblockRules' file.
-load:		Loads rules to 'adblockRules' file.
-list:		List current rules.
-reset:		Reset rules to default settings (i.e. accept all).
-help:		Help message.

