#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>
#include<unistd.h> 

#include<stdbool.h>



void DH_help(void) {

	printf(
		"\n"
		"Help:\n"
		"\n"
		"Diffie-Hellman Key Exchange Tool\n"
		"The tool will receive the required arguments from the command line upon execution as\n"
		"such:\n"
		"\n"
		"-o path	Path to output file\n"
		"-p number	Prime number\n"
		"-g number	Primitive Root for previous prime number\n"
		"-a number	Private key A\n"
		"-b number	Private key B\n"
		"-h 		This help message\n"
		"\n"
		"The argument -o will be the file name in which the results will be printed.\n"
		"The argument -p will include the will be the public prime number.\n"
		"The argument -g will be the public primitive root of the previous prime number.\n"
		"The argument -a will be the private key of user A.\n"
		"The argument -b will be the private key of user B.\n"
		"\n"
		"The command line tool will return the public key of user A, the public key of user B,\n"
		"and the shared secret. The output will be in the following format:\n"
		"<public key A>, <public key B>, <shared secret>\n"
		"\n"
		"The compiled name of the command line tool is dh_assign_1.\n"
		"\n");

	exit(EXIT_SUCCESS);
}

long long int keygen(long long int a, long long int b, long long int c){
	    
return (((long long int)pow(a,b))%c);

}

bool isPrime(long long int num) {
    if (num <= 1) {
        return false;
    }
    if (num == 2 || num == 3) {
        return true;
    }
    if (num % 2 == 0) {
        return false;
    }
    for (long long int i = 3; i <= sqrt(num); i += 2) {
        if (num % i == 0) {
            return false;
        }
    }
    return true;
}

bool isPrimitiveRoot(long long int p, long long int g) {
    if (!isPrime(p)) {
        printf("%lld is not a prime number.\n", p);
        return false;
    }

    //printf("Primitive roots of %lld are:\n", p);

    for (long long int k = 2; k < p; k++) {
        int isRoot = 1;
        for (long long int i = 1; i < p - 1; i++) {
            if (keygen(k, i, p) == 1) {
                isRoot = 0;
                break;
            }
        }
        if (isRoot && g == k ) {
        	return true;
            //printf("%lld\n", k);
        }
    }
    return false;
    //printf("%lld\n", k);
}



  

void dh_check_args(char *output_file, long long int p, long long int g, long long int a, long long int b) {

	if (!output_file) {
		printf("\nError, no output file path.\n\n");
		exit(EXIT_FAILURE);
	}

	if (!isPrime(p)) {
		printf("\nError, p must be a prime number.\n\n");
		exit(EXIT_FAILURE);
	}
	 if(!isPrimitiveRoot(p,g)){
                printf("\nError: g must be a primitive root of p-1.\n\n");
		exit(EXIT_FAILURE);
                }

	if (a < 1 || a >= p) {
		printf("\nError, private a must be between of 1 and p-1.\n\n");
		exit(EXIT_FAILURE);
	}

	if (b < 1 || b >= p) {
		printf("\nError, private b must be between of 1 and p-1.\n\n");
		exit(EXIT_FAILURE);
	}
}

int main(int argc,char **argv){

	    char *output_file; 
	    
	    // Initialize argument
	    output_file = NULL;
	       
	    long long int p, g, a, b, opt;
	    //int optcounter =0;
    
    //for every option given assign its argument's value to the proper variable  
	    while((opt = getopt(argc, argv, "o:p:g:a:b:h")) != -1) 
	    {   
		//optcounter++;
		switch(opt){   
			    case 'o': 			      // optarg is a global variable that is used to retrive the value of the argument obtained by getopt 
				output_file = strdup(optarg); // strdup dynamically allocates memory for a new string which is a duplicate of the argument
				break;
			    case 'p': 
				 p = atoi(optarg); // atoi converts string to int
				break;
			    case 'g': 
				 g = atoi(optarg);
				break; 
			    case 'a': 
				 a = atoi(optarg); 
				break;
			    case 'b': 
				 b = atoi(optarg); 
				break;  
			    case 'h':
			    	 DH_help();
			    default:printf("\nError. This argument is not an option. Run again   with -h for help.\n\n");
				exit(EXIT_FAILURE);
				break;
			} 
	    }
 
    dh_check_args(output_file, p, g, a, b);


    FILE *fptr;
    
    //Alice's public key (A)
    long long int publicA = keygen(g, a, p); // g^a mod p
     
    //Bob's public key (B)
    long long int publicB = keygen(g, b, p); //g^b mod p
 
    //Key exchange s
    long long int secretA = keygen(publicB, a, p); // B^a mod p
    long long int secretB = keygen(publicA, b, p); // A^b mod p

    if ((fptr = fopen(output_file,"w")) == NULL){
       printf("Error! opening file");
       exit(1);
   }
   fprintf(fptr,"<%lld> <%lld> <%lld>",publicA ,publicB, secretA);
   fclose(fptr);
   free(output_file);
   exit(0);
   
    
}
