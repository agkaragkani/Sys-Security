# Diffie-Hellman Key Exchange Tool

This is a command-line tool for performing the Diffie-Hellman key exchange algorithm. It allows users to generate public and private keys, perform key exchange, and save the results in an output file.

## Usage

To use the program, you need to provide the following command-line arguments:

- -o output_file_path: Path to the output file where the results will be saved.
- -p prime_number: Prime number used for key generation and key exchange.
- -g primitive_root: Primitive root corresponding to the prime number for key generation.
- -a private_key_A: Private key for user A.
- -b private_key_B: Private key for user B.
- -h: Show help message.



## Compilation

Compile the program using a C compiler (e.g., gcc):

gcc dh_assign_1.c -o dh_assign_1 -lm
## Examples 
The first example in the Makefile is the run_NOTprim:
./dh_assign_1 -o output.txt -p 23 -g 9 -a 15 -b 2
This performs the Diffie-Hellman key exchange using the specified prime number (23), primitive root (9), private key for user A (15), and private key for user B (2). The results are saved in output.txt. Due to the fact that the number (9) is not a primitive root an error message occurs.

The second one is the run_prim5:
./dh_assign_1 -o output.txt -p 23 -g 5 -a 15 -b 2
Lastly the third one is run_prim7:
./dh_assign_1 -o output.txt -p 23 -g 7 -a 15 -b 2
All the above functions can be run using the Linux Terminal calling "make" for comilation and the calling "make" again followed by the name of the wanted function. 
## Output Format
The output file must be in the following format:
<public_key_A> <public_key_B> <shared_secret>

## RSA Encryption and Decryption Tool

This is a command-line tool for RSA encryption and decryption. It allows users to generate RSA key pairs, encrypt and decrypt files, and measure the execution time for encryption and decryption operations.


## Usage

To use the program, you need to provide the following command-line arguments:

- -i input_file_path: Path to the input file.
- -o output_file_path: Path to the output file.
- -k key_file_path: Path to the key file.
- -g bit_length: Generate RSA key pairs with the specified bit length.
- -d: Decrypt input and store results in the output file.
- -e: Encrypt input and store results in the output file.
- -a time_output_file: Measure and generate execution time for different key lengths and store results in the specified output file.
- -h: Show help message.

## Compilation

Compile the program using a C compiler (e.g., gcc):


gcc -o rsa_assign_1 rsa_assign_1.c -lgmp -lm
## Generate RSA Key Pair
The first example in the Makefile for the RSA Algorithm is the run_gen:

./rsa_assign_1 -g 1024
This generates RSA key pairs with a bit length of 1024 and saves them in private_1024.key and public_1024.key.

## Encrypt File
The second one is the run_enc:
./rsa_assign_1 -i plaintext.txt -o ciphertext.txt -k public_length.key -e
This encrypts the content of plaintext.txt using the public key from public_1024.key and saves the encrypted data in ciphertext.txt.

## Decrypt File
The second one is the run_dec:
./rsa_assign_1 -i ciphertext.txt -o decrypted.txt -k private_1024.key -d
## Performance Tool

Unfortunately, it didn't work out well so we decided to leave it out completely.




## License

[MIT](https://choosealicense.com/licenses/mit/
)
MIT License
