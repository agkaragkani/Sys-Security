#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#include <getopt.h>
#include <sys/time.h>
#include <stdbool.h>
#include <gmp.h>


void timeForPerformance(char* name);
void rsa_help(void);
void generateRSAKeyPair(int bit_length, char* fileName);
void encryptFile(const char *input_path, const char *output_path, const char *key_path);
void decryptAndWriteToFile(const char *input_path, const char *output_path, const char *key_path) ;

int main(int argc, char *argv[]){

    int opt;
    char *inFile, *outFile, *keyFile;

    while((opt = getopt(argc, argv, "i:o:k:g:deah")) != -1){
        switch(opt){
            case 'i':
                inFile = strdup(optarg);
                break;
            case 'o':
                outFile = strdup(optarg);
                break;
            case 'k':
                keyFile = strdup(optarg);
                break;
            case 'g':
                generateRSAKeyPair(atoi(optarg)/2, NULL);
                break;
            case 'd':
                decryptAndWriteToFile(inFile, outFile, keyFile);
                break;
            case 'e':
                encryptFile(inFile, outFile, keyFile);
                break;
            case 'a':
                timeForPerformance(strdup(optarg));
                break;
            case 'h':
                rsa_help();
                return 0;
            default:
                fprintf(stderr, "Error.\n");
        }
    }
    return 0;
}

void rsa_help(void) {

	printf(
		"\n"
		"Help RSA Tool:\n"
		"\n"
		"The tool will receive the required arguments from the command line upon execution as\n"
		"such:\n"
		"\n"
		"-i path    Path to the input file\n"
		"-o path    Path to the output file\n"
		"-k path    Path to the key file\n"
		"-g         Perform RSA key-pair generation\n"
		"-d         Decrypt input and store results to output\n"
		"-e         Encrypt input and store results to output\n"
		"-h         This help message\n"
		"\n"
		"The arguments \"i\", \"o\" and \"k\" are always required when using \"e\" or \"d\".\n"
		"Using -i and a path the user specifies the path to the input file.\n"
		"Using -o and a path the user specifies the path to the output file.\n"
		"Using -k and a path the user specifies the path to the key file.\n"
		"Using -g the tool generates a public and a private key and\n"
		"stores them to the public.key and private.key files respectively.\n"
		"Using -d the user specifies that the tool should read the ciphertext from the input file,\n"
		"decrypt it and then store the plaintext in the output file.\n"
		"Using -e the user specifies that the tool should read the plaintext from the input file,\n"
		"encrypt it and store the ciphertext in the output file.\n"
		"\n"
		"The compiled name of the command line tool must be rsa_assign_1.\n"
		"\n");

	exit(EXIT_SUCCESS);
}

void generateRSAKeyPair(int bit_length, char* fileName) {
    
    //prime numbers
    mpz_t p, q;
    
    //n = p*q
    mpz_t n;

    //lamda = (p-1)*(q-1);
    mpz_t lamda;

    //prime 1 < e < lamda(n)
    mpz_t e;

    //Inverse modulo of (e, lamda(n))
    mpz_t d;

    mpz_inits(n, p, q, lamda, e, d, NULL);

    // Generate random p
    gmp_randstate_t state;
    gmp_randinit_default(state);

    // Seed the random number generator using the current time

    gmp_randseed_ui(state, time(NULL));

    // Check for the correct bit length
    mpz_rrandomb(p, state, bit_length);

    mpz_setbit(p, bit_length - 1);
    mpz_setbit(p, 0);

    // Make sure p is a prime number
    do {
    mpz_rrandomb(p, state, bit_length);
    mpz_setbit(p, bit_length - 1);
    mpz_setbit(p, 0);
   } while (!mpz_probab_prime_p(p, 15));

    gmp_printf("(p) is the prime number: %Zd\n", p);
    gmp_randclear(state);

    // Generate random q (same way as before for p)
    gmp_randinit_default(state);
    gmp_randseed_ui(state, time(NULL));

    mpz_rrandomb(q, state, bit_length);

    mpz_setbit(q, bit_length - 1);
    mpz_setbit(q, 0);

    do {
    mpz_rrandomb(q, state, bit_length);
    mpz_setbit(q, bit_length - 1);
    mpz_setbit(q, 0);
   } while (!mpz_probab_prime_p(q, 15) || mpz_cmp(p, q) == 0);

    gmp_printf("(q) is the prime number: %Zd\n", q);
    gmp_randclear(state);

    // Calculate variables needed //
    //  n = p*q
    mpz_mul(n, p, q);

    // lamda = (p - 1) * (q - 1)
    mpz_sub_ui(lamda, p, 1);
    mpz_sub_ui(q, q, 1);
    mpz_mul(lamda, lamda, q);

    //  d
    mpz_t one, mod, gcd;
    mpz_inits(one, mod, gcd, NULL);
    mpz_set_ui(one, 1); 

    // e
    mpz_set_ui(e, 2);

    while (mpz_cmp(lamda, e) > 0) {
        mpz_add(e, e, one); // e += 1
        mpz_mod(mod, e, lamda); // temp_mod = e % lamda
        mpz_gcd(gcd, e, lamda); 
        
        // Check 
        if (mpz_probab_prime_p(e, 40) && mpz_cmp_ui(mod, 0) != 0 && mpz_cmp_ui(gcd, 1) == 0) {
            mpz_invert(d, e, lamda); 
            break;
        }
    }

    char privateFileName[100];
    char publicFileName[100];

    if (fileName == NULL) {
        snprintf(privateFileName, sizeof(privateFileName), "private_%d.key", bit_length*2);
        snprintf(publicFileName, sizeof(publicFileName), "public_%d.key", bit_length*2);
    } else {
        snprintf(privateFileName, sizeof(privateFileName), "private_%s.key", fileName);
        snprintf(publicFileName, sizeof(publicFileName), "public_%s.key", fileName);
    }
    
    
    // Put the keys into the files created
    FILE* fp_private = fopen(privateFileName, "w");
    FILE* fp_public = fopen(publicFileName, "w");

    // Error for writing
    if (fp_private == NULL || fp_public == NULL) {
        fprintf(stderr, "Error, file didn't open for writting.\n");
        exit(1);
    }

    mpz_out_str(fp_private, 0, n);
    fprintf(fp_private, " ");
    mpz_out_str(fp_private, 0, d);

    mpz_out_str(fp_public, 0, n);
    fprintf(fp_public, " ");
    mpz_out_str(fp_public, 0, e);

    fclose(fp_private);
    fclose(fp_public);

    mpz_clears(n, p, q, lamda, e, d, one, mod, gcd, NULL);
}


void encryptFile(const char *input_path, const char *output_path, const char *key_path) {
    mpz_t n, d, inputVar;
    mpz_inits(n, d, inputVar, NULL);

    FILE *input_file = fopen(input_path, "r");
    FILE *key_file = fopen(key_path, "r");
    FILE *output_file = fopen(output_path, "w");

    if (!input_file) {
        fprintf(stderr, "Error, INPUT file .\n");
        exit(1);
    }
    
    if (!output_file) {
        fprintf(stderr, "Error, OUT file \n");
        exit(1);
    }
    
    if (!key_file) {
        fprintf(stderr, "Error, KEY file..\n");
        exit(1);
    }

    long long n_long, d_long;
    if (fscanf(key_file, "%lld %lld", &n_long, &d_long) != 2) {
        fprintf(stderr, "Error, failed to read key values from file.\n");
        exit(1);
    }

    mpz_set_si(n, n_long);
    mpz_set_si(d, d_long);

    int varb;
    while ((varb = fgetc(input_file)) != EOF) {
        mpz_init(inputVar);
        mpz_set_ui(inputVar, varb);
        mpz_powm(inputVar, inputVar, d, n);
        gmp_fprintf(output_file, "%Zd ", inputVar);
        
    }

    fclose(input_file);
    fclose(key_file);
    fclose(output_file);

    mpz_clears(n, d, inputVar, NULL);
}


void decryptAndWriteToFile(const char *input_path, const char *output_path, const char *key_path) {
    FILE *input_file = fopen(input_path, "r");
    FILE *key_file = fopen(key_path, "r");
    FILE *output_file = fopen(output_path, "w");

     if (!input_file) {
        fprintf(stderr, "Error, INPUT file.\n");
        exit(1);
    }
    
    if (!output_file) {
        fprintf(stderr, "Error, OUT file.\n");
        exit(1);
    }
    
    if (!key_file) {
        fprintf(stderr, "Error, KEY file.\n");
        exit(1);
    }

    
    mpz_t n, e, input_text;
    mpz_inits(n, e, input_text, NULL);

    long long n_long, e_long;
    if (fscanf(key_file, "%lld %lld", &n_long, &e_long) != 2) {
        fprintf(stderr, "Error, failed to read key values from file.\n");
        exit(1);
    }

    mpz_set_si(n, n_long);
    mpz_set_si(e, e_long);

    long long encrypted_word;
    while (fscanf(input_file, "%lld", &encrypted_word) != EOF) {
        mpz_set_si(input_text, encrypted_word);
        mpz_powm(input_text, input_text, e, n);
        
        char export_ch;
        mpz_export(&export_ch, NULL, 1, sizeof(char), 0, 0, input_text);
        fputc(export_ch, output_file);
    }

    fclose(input_file);
    fclose(key_file);
    fclose(output_file);

    mpz_clears(n, e, input_text, NULL);
}

void timeForPerformance(char* name) {
    
}
