# Assigment 6

Gkaragkani Alexandra, AM:2019030020

Pantazi Eva, AM:2019030021

## Description

The assignment involves getting acquainted with Snort IDS/IPS, a leading solution for network intrusion detection and prevention. Snort is well-known for its support from a robust user community and offers open-source signatures and rule sets. The objective is to create specific rules within Snort that trigger alerts when network traffic matches predefined patterns associated with malicious activity, thereby enhancing network security by detecting and preventing potential intrusions and malware propagation.
## Setting up the rules
1. Report any icmp connection attempt in test_pcap_5mins.pcap

```bash
alert icmp any any -> any any (msg:"ICMP connection attempt"; sid:1000010; rev:1;)
```

2. Find all packets which contain “hello” string in test_pcap_5mins.pcap

```bash
alert tcp any any -> any any (msg:"Packets containing 'hello' string"; content:"hello"; sid:1000002;)
```
3. Report all traffic between non root ports (port number > 1024)

```bash
alert tcp any any -> any [1025:] (msg:"Traffic between non-root ports"; sid:1000003;)
```

4. Create a rule that will detect ssh brute force attacks in sshguess.pcap file

```bash
alert tcp any any -> any 22 (msg:"SSH Brute Force Attack"; threshold: type limit, track by_src, count 10, seconds 600; sid:1000004;)
```

5. Setup the community rules (run snort with associated snort.conf) and report any clear
indicator of malicious traffic in test_pcap_5mins.pcap


## How to run
After checking that Snort is successfully installed and configured, we proceed to run the following bash commands:

Simple Rules:
```
sudo snort -r test_pcap_5mins.pcap -q -A fast -c simple.rules
sudo cat /var/log/snort/alert
```
Commuity Rules:
```
sudo snort -r test_pcap_5mins.pcap -q -A fast -c /etc/snort/snort.conf
sudo cat /var/log/snort/alert
```
## Observations
#### Traffic between non-root ports:

The alerts with SID 1000003 indicate traffic between non-root ports. In each pair of alerts, the source and destination ports are switched. This is typical behavior as Snort generates alerts for both directions of the communication.

For example:

 [1:1000003:0] Traffic between non-root ports [**] {TCP} 66.235.136.89:8443 -> 192.168.3.131:57250

[1:1000003:0] Traffic between non-root ports [**] {TCP} 192.168.3.131:57250 -> 66.235.136.89:8443

#### SSH Brute Force Attack:

   The alerts with SID 1000004 indicate a potential SSH brute force attack. The source IP 192.168.56.1
 is attempting to connect to the destination IP 192.168.56.103
 on port 22 multiple times.

For example:

[1:1000004:0] SSH Brute Force Attack [**] {TCP} 192.168.56.1:55470 -> 192.168.56.103:22

#### ICMP Connection Attempt:

This alert suggests that there was an ICMP (Internet Control Message Protocol) connection attempt from the source IP address 172.16.255.1
 to the destination IP address 67.215.65.132
.

For example:

01/25-20:56:47.823394  [1:1000010:1] ICMP connection attempt [**] [Priority: 0] {ICMP} 172.16.255.1
 -> 67.215.65.132

#### Hello String Detection:

This alert suggests that there were TCP packets from the source IP address 70.37.129.34
, source port 5480, to the destination IP address 10.0.2.15
, destination port 2553, that contained the string 'hello'. The alert provides information about the nature of the traffic, allowing you to investigate further if needed.

For example:

01/25-20:57:01.233990  [1:1000002:0] Packets containing 'hello' string [**] [Priority: 0] {TCP} 70.37.129.34:5480 -> 10.0.2.15:2553

## License

[MIT](https://choosealicense.com/licenses/mit/)
