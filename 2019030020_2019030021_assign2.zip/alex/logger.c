#define _GNU_SOURCE


#include "myLib.h"
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wdeprecated-declarations"



void compute_md5(const char* file_path, unsigned char* hash) {
    FILE* (*original_fopen)(const char*, const char*);
    FILE* fd;

    original_fopen = dlsym(RTLD_NEXT, "fopen");

    fd = original_fopen(file_path, "rb");

    if (!fd) {
        fprintf(stderr, "%s can't be opened to calculate hash value.\n", file_path);
        return;
    }

    MD5_CTX md_ctx;
    MD5_Init(&md_ctx);

    char buffer[1024];
    int md5count;

    while ((md5count = fread(buffer, 1, 1024, fd))) {
        MD5_Update(&md_ctx, buffer, md5count);
    }

    MD5_Final(hash, &md_ctx);

    fclose(fd);
}

void log_entry(const char* path, unsigned const char accessible, int isNoLog) {
    FILE* (*original_fopen)(const char*, const char*);
    original_fopen = dlsym(RTLD_NEXT, "fopen");

    char ttime[80], tdate[80], logbuff[2048], abspath[1024];
    struct tm* timeInfo;
    time_t pure_time;

    FILE* fd;
    FILE* lp;

    original_fopen = dlsym(RTLD_NEXT, "fopen");

    // get the full path
    realpath(path, abspath);

    // get time
    time(&pure_time);
    timeInfo = localtime(&pure_time);

    strftime(ttime, 80, "%T", timeInfo);
    strftime(tdate, 80, "%F", timeInfo);

    sprintf(logbuff, "\t");
    sprintf(logbuff, "%d\t%s\t%s\t%s\t%d\t%d\t\t", (unsigned int)getuid(), abspath, tdate, ttime, accessible, action_access);

    lp = original_fopen(path, "rb");

    // fill hash with zeros if isNoLog
    if (isNoLog) {
        for (int i = 0; i < MD5_DIGEST_LENGTH; i++)
            sprintf(logbuff + strlen(logbuff), "%02x", 0);
    } else {
        // compute MD5 hash
        MD5_CTX md_ctx;
        MD5_Init(&md_ctx);

        char buffer[1024];
        int md5count;

        while ((md5count = fread(buffer, 1, 1024, lp))) {
            MD5_Update(&md_ctx, buffer, md5count);
        }

        unsigned char hash[MD5_DIGEST_LENGTH];
        MD5_Final(hash, &md_ctx);

        for (md5count = 0; md5count < MD5_DIGEST_LENGTH; md5count++) {
            sprintf(logbuff + strlen(logbuff), "%02x", hash[md5count]);
        }

        fclose(lp);
    }

    sprintf(logbuff + strlen(logbuff), "\n");

    fd = original_fopen("file_logging.log", "a");

    if (!fd) {
        fprintf(stderr, "file_logging.log could not be opened.\n");
        return;
    }

    fputs(logbuff, fd);
    fclose(fd);
}




FILE* fopen(const char *path, const char *mode) 
{   
    FILE *original_fopen_ret;
    FILE *(*original_fopen)(const char*, const char*);

    /* call the original fopen function */
    original_fopen = dlsym(RTLD_NEXT, "fopen");
    FILE *my_file = original_fopen(path, mode);

    if (my_file == NULL) {
        // printf("errno = %d\n", errno);
        if (errno == EACCES || errno == EPERM) {
            // printf("Error.\n");
            action_access = 1;

            if (strcmp(mode, "w") == 0 || strcmp(mode, "w+") == 0 || strcmp(mode, "wa+") == 0) {
                log_entry(path, 0, 1);
            } else {
                log_entry(path, 1, 1);
            }
        } else if (errno == ENOENT) {
            printf("fopen failed.\n");
            return my_file;
        } else {
            return my_file;
        }
    } else {
        action_access = 0;

        if (strcmp(mode, "w") == 0 || strcmp(mode, "w+") == 0 || strcmp(mode, "wa+") == 0) {
            log_entry(path, 0, 0);
        } else {
            log_entry(path, 1, 0);
        }
    }

    original_fopen_ret = (*original_fopen)(path, mode);

    return original_fopen_ret;
}


size_t fwrite(const void *ptr, size_t size, size_t nmemb, FILE *stream) 
{
    size_t original_fwrite_ret;
    size_t (*original_fwrite)(const void*, size_t, size_t, FILE*);

    /* call the original fwrite function */
    original_fwrite = dlsym(RTLD_NEXT, "fwrite");
    original_fwrite_ret = (*original_fwrite)(ptr, size, nmemb, stream);

    fflush(stream);

    char path[1024], proc[1024];
    ssize_t path_size;

    sprintf(proc, "/proc/self/fd/%d", fileno(stream));
    path_size = readlink(proc, path, 1024);
    path[path_size] = '\0';

    log_entry(path, 2, 0);

    return original_fwrite_ret;
}

#pragma GCC diagnostic pop
