#include "myLib.h"
#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#define MAX_LINE_LENGTH 1024

// Function prototypes
void printUsage(void);
void listUnauthorizedAccesses(FILE* log);
void tokenizeLine(char* line, char* str[]);
int isUnsuccessfulAttempt(char* str[]);
void listFileModifications(FILE* log, char* fileToScan);
int isFileAccessed(char* elements[]);
int isFileModified(char* elements[], char* prevHash);

void printUsage(void)
{
    printf(
        "\n"
        "usage:\n"
        "\t./monitor \n"
        "Options:\n"
        "-m, Prints malicious users\n"
        "-i <filename>, Prints table of users that modified "
        "the file <filename> and the number of modifications\n"
        "-h, Help message\n\n"
    );

    exit(EXIT_FAILURE);
}

void listUnauthorizedAccesses(FILE* log) {
    char* line = NULL;
    size_t len = 0;

    while (getline(&line, &len, log) != -1) {
        int count = 0;
        char* str[7];
        tokenizeLine(line, str);

        if (isUnsuccessfulAttempt(str)) {
            count++;
            char* line2 = NULL;
            size_t len2 = 0;

            while (getline(&line2, &len2, log) != -1) {
                char* str2[7];
                tokenizeLine(line2, str2);

                if (isUnsuccessfulAttempt(str2) && strcmp(str[0], str2[0]) == 0 && strcmp(str[1], str2[1]) != 0) {
                    count++;
                }
            }

            if (count >= 7) {
                printf("User %s unsuccessfully tried to open seven or more files.\n", str[0]);
                break;
            }
        }
    }

    free(line);
}

void tokenizeLine(char* line, char* str[]) {
    char* element = strtok(line, "\t");

    for (int i = 0; i < 7 && element; i++) {
        str[i] = element;
        element = strtok(NULL, "\t");
    }
}

int isUnsuccessfulAttempt(char* str[]) {
    return (strcmp(str[5], "1") == 0);
}

void listFileModifications(FILE* log, char* fileToScan) {
    char* line = NULL;
    size_t len = 0;
    char givenPath[MAX_LINE_LENGTH];
    char lineHashes[MAX_LINE_LENGTH];
    char* prevHash = NULL;
    int i;
    int accessCounter = 0, counter = 0;

    realpath(fileToScan, givenPath);

    while (getline(&line, &len, log) != -1) {
        char* element;
        char* str[7];
        element = strtok(line, "\t");
        i = 0;

        while (i < 7) {
            str[i] = element;
            element = strtok(NULL, "\t");
            i++;
        }

        if ((strcmp(str[1], givenPath)) == 0) {
            if ((strcmp(str[4], "0") == 0) && (strcmp(str[5], "0") == 0)) {
                accessCounter++;
            }

            if (prevHash != NULL) {
                if ((strcmp(prevHash, str[6])) != 0) {
                    counter++;
                } else if ((strcmp(str[4], "1") == 0) && (strcmp(str[5], "0") == 0)) {
                    accessCounter++;
                }
            }

            prevHash = str[6];
            char* line2 = NULL;
            size_t len2 = 0;

            while (getline(&line2, &len2, log) != -1) {
                char* element2;
                element2 = strtok(line2, "\t");
                int k = 0;

                while (k < 7) {
                    str[k] = element2;
                    element2 = strtok(NULL, "\t");
                    k++;
                }

                if ((strcmp(str[1], givenPath) == 0) && (strcmp(prevHash, str[6]) != 0)) {
                    if ((strcmp(str[3], "1") == 0) && (strcmp(str[5], "0") == 0)) {
                        counter++;
                    }
                    prevHash = str[6];
                    break;
                } else if ((strcmp(str[1], givenPath) == 0) && (strcmp(prevHash, str[6]) == 0) && (strcmp(str[5], "0") == 0)) {
                    accessCounter++;
                }
            }
        }
    }
    printf("User accessed file: %d times and modified it: %d times.\n", accessCounter, counter);

    free(line);
}

int main(int argc, char* argv[]) {
    int ch;
    FILE* log;

    if (argc < 2)
        printUsage();

    log = fopen("./file_logging.log", "r");
    if (log == NULL) {
        printf("Error opening log file \"%s\"\n", "./file_logging.log");
        return EXIT_FAILURE;
    }

    while ((ch = getopt(argc, argv, "hi:m")) != -1) {
        switch (ch) {
        case 'i':
            listFileModifications(log, optarg);
            break;
        case 'm':
            listUnauthorizedAccesses(log);
            break;
        default:
            printUsage();
        }
    }

    fclose(log);
    argc -= optind;
    argv += optind;

    return 0;
}
