#include "myLib.h"

// Function to delete the contents of a file
void deleteFileContents(const char *filename) {
    FILE *file = fopen(filename, "w");
    if (file == NULL) {
        printf("Error opening file\n");
    } else {
        fclose(file);
    }
}

// Function to write to a file with different data
void writeDifferentDataToFile(const char *filename, const char *data) {
    FILE *file = fopen(filename, "w");
    if (file == NULL) {
        printf("Error opening file\n");
    } else {
        fprintf(file, "%s", data);
        fclose(file);
    }
}

// Function to write to a file with binary data
void writeBinaryDataToFile(const char *filename, const void *data, size_t size) {
    FILE *file = fopen(filename, "wb");
    if (file == NULL) {
        printf("Error opening file\n");
    } else {
        fwrite(data, size, 1, file);
        fclose(file);
    }
}

int main() 
{
    int index;
    size_t bytes;
    FILE *file;
    int iteration;
    char filenames[10][7] = {"file_0", "file_1", 
                             "file_2", "file_3", "file_4",
                             "file_5", "file_6", "file_7", 		
                             "file_8", "file_9"};

    // Creating files and writing data
    for (index = 0; index < 10; index++) {
        file = fopen(filenames[index], "w+");
        if (file == NULL) 
            printf("Error opening file\n");
        else {
            bytes = fwrite(filenames[index], strlen(filenames[index]), 1, file);
            fclose(file);
        }
    }

    // Modifying files and changing permissions
    for (index = 0; index < 10; index++) {
        chmod(filenames[index % 5], S_ISUID);
        file = fopen(filenames[index], "w");

        if (file == NULL) 
            printf("Error opening file\n");
        else {
            bytes = fwrite(filenames[index], strlen(filenames[index]), 1, file);
            fclose(file);
        }
        
        chmod(filenames[index], S_IRUSR);
        file = fopen(filenames[index], "r");
        
        if (file == NULL) 
            printf("Error opening file\n");
        else {
            bytes = fwrite(filenames[index], strlen(filenames[index]), 1, file);
            fclose(file);
        }
    }

    // Reading files in multiple iterations
    for (iteration = 0; iteration < 4; iteration++) {
        for (index = 0; index < 10; index++) {
            file = fopen(filenames[index], "r");
        }
    }

    // Delete contents of a file
    deleteFileContents("file_0");

    // Write to a file with different data
    writeDifferentDataToFile("file_1", "Different Data");

    // Write to a file with binary data
    int binaryData[] = {1, 2, 3, 4, 5};
    writeBinaryDataToFile("file_2", binaryData, sizeof(binaryData));
    
    return 0;
}
