#include <stdlib.h> 
#include <stdio.h>
#include <sys/socket.h>
#include <string.h> 
#include <unistd.h>
#include <signal.h>
#include <netinet/udp.h>	
#include <netinet/tcp.h>	
#include <net/ethernet.h>
#include <netinet/ip.h>	
#include <pcap.h>
#include <pcap/pcap.h>
#include <errno.h>
#include <ctype.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>


#define MAX_SNAPSHOT_LENGTH 1518
#define SIZE_OF_ETHERNET 14



struct sniff_ethernet {
        u_char  ether_dhost[ETHER_ADDR_LEN];    /* destination host address */
        u_char  ether_shost[ETHER_ADDR_LEN];    /* source host address */
        u_short ether_type;                     /* IP? ARP? RARP? etc */
};


struct sniff_ip {
        u_char  ip_vhl;                 /* version << 4 | header length >> 2 */
        u_char  ip_tos;                 /* type of service */
        u_short ip_len;                 /* total length */
        u_short ip_id;                  /* identification */
        u_short ip_off;                 /* fragment offset field */
        #define IP_RF 0x8000            /* reserved fragment flag */
        #define IP_DF 0x4000            /* dont fragment flag */
        #define IP_MF 0x2000            /* more fragments flag */
        #define IP_OFFMASK 0x1fff       /* mask for fragmenting bits */
        u_char  ip_ttl;                 /* time to live */
        u_char  ip_p;                   /* protocol */
        u_short ip_sum;                 /* checksum */
        struct  in_addr ip_src,ip_dst;  /* source and dest address */
};
#define IP_HL(ip)               (((ip)->ip_vhl) & 0x0f)
#define IP_V(ip)                (((ip)->ip_vhl) >> 4)


typedef u_int tcp_seq;

struct sniff_tcp {
        u_short th_sport;               /* source port */
        u_short th_dport;               /* destination port */
        tcp_seq th_seq;                 /* sequence number */
        tcp_seq th_ack;                 /* acknowledgement number */
        u_char  th_offx2;               /* data offset, rsvd */
	#define TH_OFF(th)      (((th)->th_offx2 & 0xf0) >> 4)
        u_char  th_flags;
        #define TH_FIN  0x01
        #define TH_SYN  0x02
		#define TH_RST  0x04
		#define TH_PUSH 0x08
		#define TH_ACK  0x10
		#define TH_URG  0x20
		#define TH_ECE  0x40
		#define TH_CWR  0x80
		#define TH_FLAGS        (TH_FIN|TH_SYN|TH_RST|TH_ACK|TH_URG|TH_ECE|TH_CWR)
        u_short th_win;                 /* window */
        u_short th_sum;                 /* checksum */
        u_short th_urp;                 /* urgent pointer */
};

struct sniff_netflow {
        u_short version;        /* NetFlow version */
        u_short count;          /* number of flows in the packet */
        u_int sys_uptime;       /* system uptime in milliseconds */
        u_int unix_secs;        /* current UNIX seconds */
        u_int unix_nsecs;       /* current UNIX nanoseconds */
        u_int flow_sequence;    /* flow sequence number */
        u_char engine_type;     /* type of flow-switching engine */
        u_char engine_id;       /* ID of the flow-switching engine */
        u_short reserved;       /* reserved field */
};


struct sniff_udp {
         u_short uh_sport;               /* source port */
         u_short uh_dport;               /* destination port */
         u_short uh_ulen;                /* udp length */
         u_short uh_sum;                 /* udp checksum */
};


int total_tcp_packets = 0;
int total_udp_packets = 0;
int total_packets = 0;
int udp_bytes = 0;
int tcp_bytes = 0;
int total_net_flows = 0;
int retransmissions = 0;


char *dev = NULL;  
FILE *log_file = NULL;




void packet_handler(u_char *param, const struct pcap_pkthdr *header, const u_char *pkt_data);
void sniff_udp(u_char *param, const struct pcap_pkthdr *header, const u_char *packet);
void sniff_tcp(u_char *param, const struct pcap_pkthdr *header, const u_char *packet);

pcap_t *handle;                  

void terminate(int signum){
	pcap_breakloop(handle);
	pcap_close(handle);
}

int main(int argc, char *argv[])
{
        
        char errbuf[PCAP_ERRBUF_SIZE];   /* error buffer */
        
        char *filter_exp = NULL;         /* filter expression [2] */
        struct bpf_program fp;           /* compiled filter program (expression) */
        bpf_u_int32 mask;                /* subnet mask */
        bpf_u_int32 net;                 /* ip */
        char opt;
        int offline = 0;
        char *file = NULL;

        while ((opt = getopt(argc, argv, "f:i:r:h")) != -1) {
            switch(opt) {
                case 'i':
                    dev = strdup(optarg);
                    break;
                case 'f':
                    filter_exp = strdup(optarg);
                    break;
                case 'r':
                    file = strdup(optarg);
                    offline = 1;
                    break;
                case 'h':
                    printf("Help Message");
                    exit(1);
                default:
                    printf("Wrong arguments\n");
                    exit(-1);
            }		
	    } 

   	 if (dev != NULL) {
         
         log_file = fopen("log.txt", "w");
         
    	 if (log_file == NULL) {
        	perror("Error opening log file");
        	exit(EXIT_FAILURE);
    }
    }
        

        
	pcap_if_t *alldevs;
	if (pcap_findalldevs(&alldevs, errbuf) == -1) {
	    fprintf(stderr, "Error in pcap_findalldevs: %s\n", errbuf);
	    exit(EXIT_FAILURE);
	}
	dev = alldevs->name;


        if (pcap_lookupnet(dev, &net, &mask, errbuf) == -1) {
            fprintf(stderr, "Couldn't get netmask for device %s: %s\n", dev, errbuf);
            net = 0;
            mask = 0;
        }

        if(offline == 0){

            handle = pcap_open_live(dev, MAX_SNAPSHOT_LENGTH, 1, 1000, errbuf);
            if (handle == NULL) {
                    fprintf(stderr, "Couldn't open device %s: %s\n", dev, errbuf);
                    exit(EXIT_FAILURE);
            }
        }else{
            handle = pcap_open_offline(file,errbuf);
        }


        if (pcap_datalink(handle) != DLT_EN10MB) {
                fprintf(stderr, "%s is not an Ethernet\n", dev);
                exit(EXIT_FAILURE);
        }

       

        signal(SIGINT, terminate);


        pcap_loop(handle, -1, packet_handler, NULL);

        printf("\nTotal number of packets: %d\n", total_packets);
        printf("Total number of tcp packets: %d\n", total_tcp_packets);
        printf("Total number of udp packets: %d\n", total_udp_packets);
        printf("Network flows: %d\n", total_net_flows);
        printf("Total number of tcp bytes: %d\n", tcp_bytes);
        printf("Total number of udp bytes: %d\n", udp_bytes);
        printf("Retransmitted packets: %d\n", retransmissions);

	pcap_freealldevs(alldevs);

        return 0;
        
}

void sniff_udp(u_char *param, const struct pcap_pkthdr *header, const u_char *packet){

    const struct sniff_ethernet *ethernet;  /* The ethernet header [1] */
    const struct sniff_ip *ip;              /* The IP header */
    const struct sniff_udp *udp;            /* The UDP header */
    const char *payload;                    /* Packet payload */

    udp_bytes += header->len;

    int size_ip;
    int size_udp;
    int size_payload;

    total_udp_packets++;


    ethernet = (struct sniff_ethernet*)(packet);


    ip = (struct sniff_ip*)(packet + SIZE_OF_ETHERNET);
    size_ip = IP_HL(ip)*4;
    if (size_ip < 20) {
        printf("Error: IP header length is invalid: %u bytes\n", size_ip);
        return;
    }


    printf("[--]Source IP: %s\n", inet_ntoa(ip->ip_src));
    printf("[--]Destination IP: %s\n", inet_ntoa(ip->ip_dst));


    udp = (struct sniff_udp*)(packet + SIZE_OF_ETHERNET + size_ip);


    payload = (u_char *)(packet + SIZE_OF_ETHERNET + size_ip + 8);

    
	size_payload =ntohs(udp->uh_ulen) - sizeof(struct udphdr);
	
	

    printf("[--]Source port: %d\n", ntohs(udp->uh_sport));
    printf("[--]Destination port: %d\n", ntohs(udp->uh_dport));

    if (ntohs(udp->uh_sport) == 2055 || ntohs(udp->uh_dport) == 2055)
        total_net_flows++;


    if (size_payload > 0) {
        printf("[--]Payload (%d bytes):\n", size_payload);
    }
    
    if (dev != NULL && log_file != NULL) {
        fprintf(log_file, "[--]Protocol: %s\n", "UDP");
        fprintf(log_file, "[--]Source IP: %s\n", inet_ntoa(ip->ip_src));
        fprintf(log_file, "[--]Destination IP: %s\n", inet_ntoa(ip->ip_dst));
        fprintf(log_file, "[--]Source port: %d\n", ntohs(udp->uh_sport));
        fprintf(log_file, "[--]Destination port: %d\n", ntohs(udp->uh_dport));

        if (size_payload > 0) {
            fprintf(log_file, "[--]Payload (%d bytes):\n", size_payload);
        }
        fprintf(log_file, "\n");
        fflush(log_file);  // Flush the buffer to ensure the content is written immediately
    }

}

void sniff_tcp(u_char *param, const struct pcap_pkthdr *header, const u_char *pkt_data){
    
        const struct sniff_ethernet *ethernet;  /* The ethernet header [1] */
        const struct sniff_ip *ip;              /* The IP header */
        const struct sniff_tcp *tcp;            /* The TCP header */
        u_char *payload;                        /* Packet payload */

        tcp_bytes += header->len;

        int size_ip;
        int size_tcp;
        int size_payload;


        total_tcp_packets++;


        ethernet = (struct sniff_ethernet*)(pkt_data);


        ip = (struct sniff_ip*)(pkt_data + SIZE_OF_ETHERNET);
        size_ip = IP_HL(ip)*4;
        if (size_ip < 20) {
                printf("Error: IP header length is invalid: %u bytes\n", size_ip);
                return;
        }


	tcp = (struct sniff_tcp*)(pkt_data + SIZE_OF_ETHERNET + size_ip);
        size_tcp = TH_OFF(tcp)*4;
        if (size_tcp < 20) {
                printf("Error: TCP header length is invalid: %u bytes\n", size_tcp);
                return;
        }


        payload = (u_char *)(pkt_data + SIZE_OF_ETHERNET + size_ip + size_tcp);


        size_payload = ntohs(ip->ip_len) - (size_ip + size_tcp);

        if (ntohs(tcp->th_dport) == 2055 || ntohs(tcp->th_dport) == 2055)
            total_net_flows++;


        if (tcp->th_flags & TH_RST) {
                retransmissions++;
        }
        
    if (dev != NULL && log_file != NULL) {
        fprintf(log_file, "[--]Protocol: %s\n", "TCP");
        fprintf(log_file, "[--]Source IP: %s\n", inet_ntoa(ip->ip_src));
        fprintf(log_file, "[--]Destination IP: %s\n", inet_ntoa(ip->ip_dst));
        fprintf(log_file, "[--]Source port: %d\n", ntohs(tcp->th_sport));
        fprintf(log_file, "[--]Destination port: %d\n", ntohs(tcp->th_dport));

        if (size_payload > 0) {
            fprintf(log_file, "[--]Payload (%d bytes):\n", size_payload);
        }
        fprintf(log_file, "\n");
        fflush(log_file);  // Flush the buffer to ensure the content is written immediately
    }
        
}


void packet_handler(u_char *param, const struct pcap_pkthdr *header, const u_char *pkt_data)
{

        const struct sniff_ethernet *ethernet;  /* The ethernet header [1] */
        const struct sniff_ip *ip;              /* The IP header */

        int size_ip;
        int size_tcp;
        int size_payload;


        total_packets++;


        ethernet = (struct sniff_ethernet*)(pkt_data);


        ip = (struct sniff_ip*)(pkt_data + SIZE_OF_ETHERNET);
        size_ip = IP_HL(ip)*4;
        if (size_ip < 20) {
                printf("Error: IP header length is invalid: %u bytes\n", size_ip);
                return;
        }

        switch(ip->ip_p) {
            case IPPROTO_TCP:
                 sniff_tcp(param, header,pkt_data);
                 break;
            case IPPROTO_UDP:
                 sniff_udp(param, header,pkt_data);
                 break;
            default:
                 printf("Error: Protocol is unknown\n");
                 return;
 }

}
