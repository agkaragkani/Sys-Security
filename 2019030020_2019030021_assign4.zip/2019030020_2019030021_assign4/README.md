 Assignment 4
## Network Traffic Analyzer

This C program captures and analyzes network traffic using the libpcap library. It provides information about TCP and UDP packets, including details such as source and destination IP addresses, ports, payload size, and flags. The program also detects retransmitted TCP packets and counts network flows.

## Options

-i <interface>: Specify the network interface to capture live traffic.  
-f <filter_expression>: Apply a BPF filter expression to capture specific traffic.  
-r <file>: Read packets from a pcap file (offline mode).  
-h: Display the help message.

## Execute


#### For live capture:  #### 
   sudo ./pcap_ex -i enp0s3  
 sudo ./pcap_ex -i enp0s3 -f "src port 53"    

#### For file capture:   ####          
  ./pcap_ex -r test_pcap_5mins.pcap  
#### For help message:   
sudo ./pcap_ex -h
#### Terminate
It breaks the packet capture loop (pcap_breakloop) and closes the pcap handle when the user interrupts the program by pressing Ctrl+C.

## Using libpcap

We use the capabilities of the libpcap library, through pcap_open_offline(pcap_file, err) and pcap_loop() functions for processing pcap file data. Information about the library was given from the sites: https://linux.die.net/man/3/pcap

 and https://www.tcpdump.org

 .


## Implementation
The program includes functionality to log packet information into a file named "log.txt."  
We use these functions to handle the packets:   
1. sniff_udp: Processes and prints information about UDP packets.  
2. sniff_tcp: Processes and prints information about TCP packets.  
3. packet_handler: Determines the protocol (TCP or UDP) and calls the corresponding packet handling function.

## Questions
10. Can you tell if an incoming TCP packet is a retransmission? If yes, how? If not, why?  

Yes, they can be retransmitted and we know from the header's bytes in the sniff_tcp function which also contains a check for TCP reset flag(TH_RST) which determines the termination of a connection and it is also a sign of a failed transmission attempt.

11. Can you tell if an incoming UDP packet is a retransmission? If yes, how? If not, why?

Retransmissions are typically associated with TCP rather than UDP because UDP is a connectionless protocol that doesn't provide mechanisms for acknowledgemet, retransmission or flow control.

## License

[MIT](https://choosealicense.com/licenses/mit/

)
